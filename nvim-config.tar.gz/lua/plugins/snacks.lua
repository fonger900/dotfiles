-- =============================================
-- Snacks Plugins
-- =============================================

---@diagnostic disable: undefined-global
return {
  "folke/snacks.nvim",
  event = "VeryLazy",
  opts = {
    bigfile = { enabled = true },
    dashboard = { enabled = true },
    explorer = {
      enabled = true,
      replace_netrw = true,  -- Replace netrw with Snacks explorer
    },
    gh = { enabled = true }, -- GitHub CLI integration
    indent = { enabled = true },
    input = { enabled = true },
    notifier = {
      enabled = true,
      timeout = 3000,
    },
    picker = {
      enabled = true,
      ui = { border = "rounded" },
      sources = {
        files = { hidden = true, follow = true },
        grep = { hidden = true, follow = true },
        explorer = {
          hidden = true, -- Show hidden files (dotfiles) by default
          -- ignored = true, -- Optional: Uncomment to also show git-ignored files
        },
      },
    },
    profiler = { enabled = false },
    quickfile = { enabled = true },
    scope = { enabled = false },
    statuscolumn = { enabled = true },
    words = { enabled = true },
    styles = {
      notification = {
        -- wo = { wrap = true } -- Wrap notifications
      }
    }
  },
  keys = {
    -- Core pickers
    { "<leader><space>", function() Snacks.picker.smart() end,                                   desc = "Smart Find Files" },
    { "<leader>,",       function() Snacks.picker.buffers() end,                                 desc = "Buffers" },
    { "<leader>/",       function() Snacks.picker.grep() end,                                    desc = "Grep" },
    { "<leader>:",       function() Snacks.picker.command_history() end,                         desc = "Command History" },
    { "<leader>n",       function() Snacks.notifier.show_history() end,                          desc = "Notification History" },
    { "<leader>e",       function() Snacks.explorer() end,                                       desc = "File Explorer" },

    -- Find files
    { "<leader>ff",      function() Snacks.picker.files() end,                                   desc = "Find Files" },
    { "<leader>fr",      function() Snacks.picker.recent() end,                                  desc = "Recent" },
    { "<leader>fR",      function() Snacks.picker.recent({ cwd = vim.uv.cwd() }) end,            desc = "Recent (cwd)" },
    { "<leader>fc",      function() Snacks.picker.files({ cwd = vim.fn.stdpath("config") }) end, desc = "Find Config File" },
    { "<leader>fg",      function() Snacks.picker.git_files() end,                               desc = "Find Git Files" },
    { "<leader>f.",      function() Snacks.quickfile() end,                                      desc = "Quickfile" },

    -- Search/grep
    { "<leader>sw",      function() Snacks.picker.grep_word() end,                               desc = "Visual selection or word",   mode = { "n", "x" } },
    { "<leader>sB",      function() Snacks.picker.grep_buffers() end,                            desc = "Grep Open Buffers" },
    { "<leader>sb",      function() Snacks.picker.lines() end,                                   desc = "Buffer Lines" },

    -- Diagnostics & LSP
    { "<leader>sd",      function() Snacks.picker.diagnostics() end,                             desc = "Workspace diagnostics" },
    { "<leader>sD",      function() Snacks.picker.diagnostics_buffer() end,                      desc = "Document diagnostics" },
    { "<leader>ss",      function() Snacks.picker.lsp_symbols() end,                             desc = "LSP Symbols" },
    { "<leader>sS",      function() Snacks.picker.lsp_workspace_symbols() end,                   desc = "LSP Workspace Symbols" },

    -- Help & info
    { "<leader>sH",      function() Snacks.picker.help() end,                                    desc = "Help Pages" },
    { "<leader>sk",      function() Snacks.picker.keymaps() end,                                 desc = "Keymaps" },
    { "<leader>sc",      function() Snacks.picker.commands() end,                                desc = "Commands" },
    { "<leader>sr",      function() Snacks.picker.registers() end,                               desc = "Registers" },
    { "<leader>sm",      function() Snacks.picker.marks() end,                                   desc = "Marks" },
    { "<leader>sj",      function() Snacks.picker.jumps() end,                                   desc = "Jumps" },
    { "<leader>su",      function() Snacks.picker.undo() end,                                    desc = "Undo History" },
    { "<leader>uC",      function() Snacks.picker.colorschemes() end,                            desc = "Colorscheme with preview" },

    -- Git
    { "<leader>gb",      function() Snacks.picker.git_branches() end,                            desc = "Git Branches" },
    { "<leader>gl",      function() Snacks.picker.git_log() end,                                 desc = "Git Log" },
    { "<leader>gL",      function() Snacks.picker.git_log_line() end,                            desc = "Git Log Line" },
    { "<leader>gs",      function() Snacks.picker.git_status() end,                              desc = "Git Status" },
    { "<leader>gS",      function() Snacks.picker.git_stash() end,                               desc = "Git Stash" },
    { "<leader>gd",      function() Snacks.picker.git_diff() end,                                desc = "Git Diff (Hunks)" },
    { "<leader>gf",      function() Snacks.picker.git_log_file() end,                            desc = "Git Log File" },

    -- GitHub (requires GitHub CLI)
    { "<leader>ghi",     function() Snacks.picker.gh_issue() end,                                desc = "GitHub Issues (open)" },
    { "<leader>ghI",     function() Snacks.picker.gh_issue({ state = "all" }) end,               desc = "GitHub Issues (all)" },
    { "<leader>ghp",     function() Snacks.picker.gh_pr() end,                                   desc = "GitHub Pull Requests (open)" },
    { "<leader>ghP",     function() Snacks.picker.gh_pr({ state = "all" }) end,                  desc = "GitHub Pull Requests (all)" },

    -- LSP navigation (replaces telescope/native LSP bindings)
    { "gd",              function() Snacks.picker.lsp_definitions() end,                         desc = "Goto Definition" },
    { "gD",              function() Snacks.picker.lsp_declarations() end,                        desc = "Goto Declaration" },
    { "gr",              function() Snacks.picker.lsp_references() end,                          nowait = true,                       desc = "References" },
    { "gI",              function() Snacks.picker.lsp_implementations() end,                     desc = "Goto Implementation" },
    { "gy",              function() Snacks.picker.lsp_type_definitions() end,                    desc = "Goto T[y]pe Definition" },

    -- Other features
    { "<leader>z",       function() Snacks.zen() end,                                            desc = "Toggle Zen Mode" },
    { "<leader>Z",       function() Snacks.zen.zoom() end,                                       desc = "Toggle Zoom" },
    { "<leader>.",       function() Snacks.scratch() end,                                        desc = "Toggle Scratch Buffer" },
    { "<leader>S",       function() Snacks.scratch.select() end,                                 desc = "Select Scratch Buffer" },
    { "<leader>bd",      function() Snacks.bufdelete() end,                                      desc = "Delete Buffer" },
    { "<leader>cR",      function() Snacks.rename.rename_file() end,                             desc = "Rename File" },
    { "<leader>gB",      function() Snacks.gitbrowse() end,                                      desc = "Git Browse",                 mode = { "n", "v" } },
    { "<leader>gg",      function() Snacks.lazygit() end,                                        desc = "Lazygit" },
    { "<leader>un",      function() Snacks.notifier.hide() end,                                  desc = "Dismiss All Notifications" },
    { "<c-/>",           function() Snacks.terminal() end,                                       desc = "Toggle Terminal" },
    { "<c-_>",           function() Snacks.terminal() end,                                       desc = "which_key_ignore" },
    { "]]",              function() Snacks.words.jump(vim.v.count1) end,                         desc = "Next Reference",             mode = { "n", "t" } },
    { "[[",              function() Snacks.words.jump(-vim.v.count1) end,                        desc = "Prev Reference",             mode = { "n", "t" } },
  },
  config = function(_, opts)
    local snacks = require("snacks")
    snacks.setup(opts)
    _G.Snacks = snacks

    local toggles = {
      { "<leader>us", snacks.toggle.option("spell", { name = "Spelling" }) },
      { "<leader>uw", snacks.toggle.option("wrap", { name = "Wrap" }) },
      { "<leader>uL", snacks.toggle.option("relativenumber", { name = "Relative Number" }) },
      { "<leader>ud", snacks.toggle.diagnostics() },
      { "<leader>ul", snacks.toggle.line_number() },
      { "<leader>uc", snacks.toggle.option("conceallevel", { off = 0, on = vim.o.conceallevel > 0 and vim.o.conceallevel or 2 }) },
      { "<leader>uT", snacks.toggle.treesitter() },
      { "<leader>ub", snacks.toggle.option("background", { off = "light", on = "dark", name = "Dark Background" }) },
      { "<leader>uh", snacks.toggle.inlay_hints() },
      { "<leader>ug", snacks.toggle.indent() },
      { "<leader>uD", snacks.toggle.dim() },
    }

    for _, toggle in ipairs(toggles) do
      toggle[2]:map(toggle[1])
    end
  end,
}

-- =============================================
-- Project-specific configuration
-- =============================================
--
-- To override the default configuration for a specific project, you can create
-- a `.nvim.lua` file in the root of your project. This file will be
-- automatically loaded by Neovim.
--
-- For example, to disable the dashboard for a specific project, you can
-- create a `.nvim.lua` file with the following content:
--
-- return {
--   "folke/snacks.nvim",
--   opts = {
--     dashboard = { enabled = false },
--   },
-- }
--
